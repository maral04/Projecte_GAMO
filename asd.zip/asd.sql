-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.9 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.3.0.5072
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for gamodb
CREATE DATABASE IF NOT EXISTS `gamodb` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci */;
USE `gamodb`;

-- Dumping structure for table gamodb.administrador
CREATE TABLE IF NOT EXISTS `administrador` (
  `PK_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(25) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  `contrassenya` varchar(25) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  `Email` varchar(25) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`PK_Id`),
  UNIQUE KEY `contrassenya` (`contrassenya`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.camps
CREATE TABLE IF NOT EXISTS `camps` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Tipus` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Opcions` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.camp_prova
CREATE TABLE IF NOT EXISTS `camp_prova` (
  `id_prova` int(11) DEFAULT NULL,
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `id_camp` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_id_prova` (`id_prova`),
  KEY `FK_id_camp` (`id_camp`),
  CONSTRAINT `FK_id_camp` FOREIGN KEY (`id_camp`) REFERENCES `camps` (`Id`),
  CONSTRAINT `FK_id_prova` FOREIGN KEY (`id_prova`) REFERENCES `prova` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.esport
CREATE TABLE IF NOT EXISTS `esport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.event
CREATE TABLE IF NOT EXISTS `event` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FK_Id_Organitzador` varchar(9) COLLATE latin1_spanish_ci NOT NULL,
  `FK_Id_Prova` int(11) NOT NULL,
  `Titol` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `DataInici` datetime NOT NULL,
  `DataFinal` datetime NOT NULL,
  `Descripcio` text COLLATE latin1_spanish_ci NOT NULL,
  `Validated` int(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Id_Organitzador` (`FK_Id_Organitzador`),
  KEY `FKFK_Id_Prova` (`FK_Id_Prova`),
  CONSTRAINT `FKFK_Id_Prova` FOREIGN KEY (`FK_Id_Prova`) REFERENCES `prova` (`Id`),
  CONSTRAINT `FK_Id_Organitzador` FOREIGN KEY (`FK_Id_Organitzador`) REFERENCES `organitzador` (`Dni`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.inscripcio
CREATE TABLE IF NOT EXISTS `inscripcio` (
  `Idinscripcio` int(11) NOT NULL AUTO_INCREMENT,
  `FK_id_prova` int(11) NOT NULL,
  `id_participant` int(11) NOT NULL,
  `Data_ hora` datetime NOT NULL,
  PRIMARY KEY (`Idinscripcio`),
  KEY `FK_prova` (`FK_id_prova`),
  KEY `FK_participant` (`id_participant`),
  CONSTRAINT `FK_participant` FOREIGN KEY (`id_participant`) REFERENCES `participant` (`FK_Id_Usuari`),
  CONSTRAINT `FK_prova` FOREIGN KEY (`FK_id_prova`) REFERENCES `prova` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.inscripcio_camp
CREATE TABLE IF NOT EXISTS `inscripcio_camp` (
  `FK_id_camp` int(11) NOT NULL,
  `FK_id_inscripcio` int(11) NOT NULL,
  `valor` int(11) NOT NULL,
  KEY `FK_camp` (`FK_id_camp`),
  KEY `FKIns` (`FK_id_inscripcio`),
  CONSTRAINT `FKIns` FOREIGN KEY (`FK_id_inscripcio`) REFERENCES `inscripcio` (`Idinscripcio`),
  CONSTRAINT `FK_camp` FOREIGN KEY (`FK_id_camp`) REFERENCES `camps` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.localitzacio
CREATE TABLE IF NOT EXISTS `localitzacio` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CP` int(11) NOT NULL DEFAULT '0',
  `Estat` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  `Regio` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  `Poblacio` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  `Direccio` varchar(50) COLLATE latin1_spanish_ci DEFAULT '0',
  `coordenades` varchar(11) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.noticia
CREATE TABLE IF NOT EXISTS `noticia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Titol` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `DataCeracio` datetime NOT NULL,
  `FK_dataProva_Prova` datetime NOT NULL,
  `Text` text COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_dataProva_Prova` (`FK_dataProva_Prova`),
  CONSTRAINT `FK_dataProva_Prova` FOREIGN KEY (`FK_dataProva_Prova`) REFERENCES `prova` (`Data_hora_inici`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.organitzador
CREATE TABLE IF NOT EXISTS `organitzador` (
  `Dni` varchar(9) COLLATE latin1_spanish_ci NOT NULL,
  `Valoracio` float NOT NULL,
  `Trusty` varbinary(5) NOT NULL,
  `FK_IdUsuari_Usuari` int(11) NOT NULL,
  `FK_IdEvent_Event` varchar(9) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`Dni`),
  KEY `FK_IdUsuari_Usuari` (`FK_IdUsuari_Usuari`),
  CONSTRAINT `FK_IdUsuari_Usuari` FOREIGN KEY (`FK_IdUsuari_Usuari`) REFERENCES `usuari` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.participant
CREATE TABLE IF NOT EXISTS `participant` (
  `Dni` varchar(9) COLLATE latin1_spanish_ci NOT NULL,
  `FK_Id_Usuari` int(11) NOT NULL,
  `Numfederat` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`FK_Id_Usuari`),
  CONSTRAINT `FK_Id_Usuari` FOREIGN KEY (`FK_Id_Usuari`) REFERENCES `usuari` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.prova
CREATE TABLE IF NOT EXISTS `prova` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FK_Id_event` int(11) NOT NULL DEFAULT '0',
  `FK_Id_esport` int(11) NOT NULL DEFAULT '0',
  `FK_Id_Localitzacio` int(11) NOT NULL DEFAULT '0',
  `FK_IdValoracio_Valoracio` int(11) NOT NULL DEFAULT '0',
  `Preu` double NOT NULL DEFAULT '0',
  `Distancia` int(11) NOT NULL DEFAULT '0',
  `DesnivellPositiu` int(11) NOT NULL DEFAULT '0',
  `DesnivellNegatiu` int(11) NOT NULL DEFAULT '0',
  `DesnivellAcumulat` int(11) NOT NULL DEFAULT '0',
  `num_avituallaments` int(11) unsigned NOT NULL,
  `Nom` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Modalitat` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Recorregut` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Imatges` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `pagina_organitzacio` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Validated` double NOT NULL DEFAULT '0',
  `Descripcio` text COLLATE latin1_spanish_ci NOT NULL,
  `Data_hora_inici` datetime NOT NULL,
  `Obertura_inscripcions` datetime NOT NULL,
  `Tancament_inscripcionts` datetime NOT NULL,
  `Limit_inscripcio` datetime NOT NULL,
  `Temps_limit` double NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Id_Localitzacio_Prova` (`FK_Id_Localitzacio`),
  KEY `FKFK_IdValoracio_Valoracio` (`FK_IdValoracio_Valoracio`),
  KEY `FK_Id_esport` (`FK_Id_esport`),
  KEY `Data_hora_inici` (`Data_hora_inici`),
  CONSTRAINT `FKFK_IdValoracio_Valoracio` FOREIGN KEY (`FK_IdValoracio_Valoracio`) REFERENCES `valoracio` (`Id`),
  CONSTRAINT `FK_Id_Localitzacio_Prova` FOREIGN KEY (`FK_Id_Localitzacio`) REFERENCES `localitzacio` (`Id`),
  CONSTRAINT `FK_Id_esport` FOREIGN KEY (`FK_Id_esport`) REFERENCES `esport` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.usuari
CREATE TABLE IF NOT EXISTS `usuari` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FK_Nom_Esport` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `FK_Id_Localitzacio` int(11) NOT NULL DEFAULT '0',
  `Fk_id_Admin` int(11) NOT NULL DEFAULT '0',
  `telefon` int(9) NOT NULL DEFAULT '0',
  `Email` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  `Contrassenya` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  `Nom` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  `Cnom` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Id_Localitzacio` (`FK_Id_Localitzacio`),
  KEY `Fk_id_Admin` (`Fk_id_Admin`),
  CONSTRAINT `FK_Id_Localitzacio` FOREIGN KEY (`FK_Id_Localitzacio`) REFERENCES `localitzacio` (`Id`),
  CONSTRAINT `Fk_id_Admin` FOREIGN KEY (`Fk_id_Admin`) REFERENCES `administrador` (`PK_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
-- Dumping structure for table gamodb.valoracio
CREATE TABLE IF NOT EXISTS `valoracio` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` double NOT NULL DEFAULT '0',
  `FK_idProva_Prova` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `FK_idProva_Prova` (`FK_idProva_Prova`),
  CONSTRAINT `FK_idProva_Prova` FOREIGN KEY (`FK_idProva_Prova`) REFERENCES `prova` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
